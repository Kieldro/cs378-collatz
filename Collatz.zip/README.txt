Course Name: CS 378
Unique: 
First Name: Ian
Last Name: Buitrago
EID: ib
CS Username: keo
GitHub ID: Kieldro
GitHub Repository Name: cs378-collatz
Estimated number of hours: 10
Actual    number of hours: 12
Comments:
questions:
* tab vs 2 space indention
* convention/style
* failure test is a test that always fail eg x = 0?
* git mv f1 f2
* how does hashbang work?
* how do you echo command then execute elegantly?

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
